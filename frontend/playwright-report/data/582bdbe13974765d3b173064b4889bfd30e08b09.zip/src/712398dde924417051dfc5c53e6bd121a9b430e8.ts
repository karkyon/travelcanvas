import { test, expect, type Page } from '@playwright/test';

/**
 * [Gate M10 v7] 中核機能Playwright browser E2E拡張。
 *
 * FR-013文書ウォレット(DocumentsPage)は、Gate M5(Object Storage実連携)・
 * Gate M6(実アップロードUI接続)・Gate M7(P0-01〜P0-04/P1-01/P1-02安全化)
 * を経てAPI/backend側は348件超のテストで検証済みだったが、browser E2Eは
 * 一件も存在しなかった(quickdraft-flow.spec.tsとa11y.spec.tsの2本のみ)。
 * 本ファイルは「アップロード → 一覧表示 → ダウンロード → 削除」という
 * 実際のユーザー操作の連なりを、実ブラウザ上で検証する。
 *
 * [v7差分] v2〜v6は、失敗する行ごとに個別のtry/catchで診断メッセージを
 * 都度書き足す対症療法を繰り返しており、新しい行で失敗するたびに
 * 診断情報が不足するということを何度も繰り返していた(v5のエラー
 * バナーのみ→v6でHTTPエラー本文/requestfailedを追加→それでも
 * getByText(file.name)の失敗には一切適用されていなかった、等)。
 * v7ではこの構造的な問題を解消するため、各testの本体全体を1つの
 * try/catchで包み、"どのアサーションで失敗しても"必ず
 * attachDiagnostics()が収集した全情報(nav履歴/HTTPレスポンス本文/
 * requestfailed/JS例外/console全ログ)をエラーメッセージへ含める
 * ようにした。個別のヘルパー関数(waitForUploadDialogToClose等)は
 * 診断整形を持たず、素のエラーを投げるだけにし、診断の付与は
 * テスト本体の外側catchに一本化した。以後、新しい失敗パターンが
 * 出てきても、この一元化された仕組みにより自動的に十分な診断が
 * 得られる。
 *
 * [v6での実バグ修正の経緯] v5まではモーダルが閉じない問題が発生して
 * いた。v6の診断強化で原因を特定した結果、frontend/src/services/api.ts
 * のuploadDocument()がaxiosへFormDataを渡す際にContent-Typeヘッダーを
 * 明示指定していたため、ブラウザが自動付与するmultipartのboundary
 * パラメータが欠落し、backend側がリクエストを解析できずアップロードが
 * 失敗していた(axios利用時の既知の落とし穴、Gate M6以来の実バグ)。
 * この修正によりモーダルは正しく閉じるようになったが、続けて
 * アップロード後に一覧へファイル名が反映されない問題が新たに判明した
 * ため、v7の診断強化で原因を特定する。
 *
 * 前提: backend/app/services/storage_backend.py の validate_upload() は
 * 拡張子に対応するマジックナンバー(.pdfなら先頭"%PDF-")を検証するため、
 * テスト用ファイルは実際のPDFマジックナンバーを含むバイト列を使う。
 *
 * restricted分類のcross-user(所有者以外の共同編集者)アクセス拒否
 * (2026-09-13総合再監査P0-03)は、backend/tests/test_gate_m7_document_hardening.py
 * で既にAPIレベルで9ケース検証済み。同シナリオをbrowser E2Eとして
 * 再現するには、実登録ユーザー2名+共同編集者招待(SharePage)の
 * オーケストレーションが必要となり、本Gateではその複雑さに見合う
 * 追加の検出力(APIレベルのテストで既にowner本人以外への404を確認済み)
 * が無いと判断し、意図的にスコープ外とした。本ファイルでは、所有者
 * 自身がrestricted分類の文書を正しく作成・閲覧できること(分類UIの
 * 疎通確認)までを検証する。
 */

function pdfFile(nameSuffix: string) {
  return {
    name: `e2e-receipt-${nameSuffix}.pdf`,
    mimeType: 'application/pdf',
    buffer: Buffer.from(`%PDF-1.4\n% E2E test fixture ${nameSuffix}\n%%EOF\n`, 'utf-8'),
  };
}

type Diagnostics = {
  navCount: number;
  navUrls: string[];
  httpLog: string[];
  requestFailures: string[];
  pageErrors: string[];
  consoleMessages: string[];
};

/** quickdraft-flow.spec.ts v5と同じ診断フック。フレーム遷移・HTTP応答
 * (本文含む、成功/失敗問わず documents 関連は全件)・requestfailed・
 * JS例外・consoleを記録し、失敗時の原因切り分けに使う。 */
function attachDiagnostics(page: Page): Diagnostics {
  const state: Diagnostics = {
    navCount: 0,
    navUrls: [],
    httpLog: [],
    requestFailures: [],
    pageErrors: [],
    consoleMessages: [],
  };
  page.on('framenavigated', (frame) => {
    if (frame === page.mainFrame()) {
      state.navCount += 1;
      state.navUrls.push(frame.url());
    }
  });
  page.on('response', (response) => {
    const url = response.url();
    // documents関連のAPI呼び出しは成功/失敗を問わず全件記録する
    // (「一覧に反映されない」系の失敗は200 OKでも中身が空/想定外である
    // 可能性があり、エラー応答だけを見ていては原因が分からないため)。
    const isDocumentsApi = url.includes('/documents');
    const isError = response.status() >= 400;
    if (isDocumentsApi || isError) {
      void response
        .text()
        .catch(() => '(本文取得失敗)')
        .then((body) => {
          state.httpLog.push(
            `[HTTP ${response.status()}] ${response.request().method()} ${url} body=${body.slice(0, 500)}`,
          );
        });
    }
  });
  page.on('requestfailed', (request) => {
    state.requestFailures.push(
      `[REQUEST FAILED] ${request.method()} ${request.url()} reason=${request.failure()?.errorText ?? '不明'}`,
    );
  });
  page.on('pageerror', (err) => {
    state.pageErrors.push(err.message);
  });
  page.on('console', (msg) => {
    const type = msg.type();
    if (type === 'log' || type === 'warning' || type === 'error') {
      state.consoleMessages.push(`[console.${type}] ${msg.text()}`);
    }
  });
  return state;
}

function diagnosticsSummary(state: Diagnostics): string {
  return (
    `\n===== 診断情報 =====\n` +
    `nav回数=${state.navCount}件\n` +
    `遷移先URL一覧: ${state.navUrls.length ? state.navUrls.map((u, i) => `\n  ${i + 1}. ${u}`).join('') : 'なし'}\n` +
    `HTTP応答(documents関連または4xx/5xx、本文含む): ${
      state.httpLog.length ? state.httpLog.map((m, i) => `\n  ${i + 1}. ${m}`).join('') : 'なし'
    }\n` +
    `requestfailed: ${
      state.requestFailures.length ? state.requestFailures.map((m, i) => `\n  ${i + 1}. ${m}`).join('') : 'なし'
    }\n` +
    `JS例外: ${state.pageErrors.length ? state.pageErrors.join(' / ') : 'なし'}\n` +
    `consoleログ(直近30件): ${
      state.consoleMessages.length
        ? state.consoleMessages.slice(-30).map((m, i) => `\n  ${i + 1}. ${m}`).join('')
        : 'なし'
    }\n` +
    `=====================`
  );
}

/** quickdraft-flow.spec.ts と同じ導線で、匿名ゲストとして新規プランを作成し
 * /planner/{planId} へ遷移した状態にする。 */
async function createGuestPlan(page: Page, titleSuffix: string) {
  await page.goto('/');
  await page.getByRole('button', { name: /ゲストとして始める/ }).click();
  await page.waitForURL(/\/planner\/?$/, { timeout: 15_000 });

  const newPlanButton = page.getByRole('button', { name: /新しいプラン/ });
  await newPlanButton.waitFor({ state: 'visible', timeout: 15_000 });
  await newPlanButton.click();

  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.getByPlaceholder('例: 東京旅行').fill(`M10文書E2E-${titleSuffix}`);
  await dialog.getByRole('button', { name: '作成' }).click();

  await page.waitForURL(/\/planner\/[0-9a-fA-F-]{36}$/, { timeout: 15_000 });
  const match = page.url().match(/\/planner\/([0-9a-fA-F-]{36})/);
  if (!match) throw new Error(`planId をURLから取得できませんでした: ${page.url()}`);
  return match[1];
}

async function openDocumentsPage(page: Page, planId: string) {
  await page.getByRole('button', { name: /📄\s*文書/ }).click();
  await page.waitForURL(new RegExp(`/planner/${planId}/documents$`), { timeout: 15_000 });
  const uploadButton = page.getByRole('button', { name: '新規アップロード' });
  await uploadButton.waitFor({ state: 'visible', timeout: 20_000 });
  return uploadButton;
}

async function fillAndSubmitUpload(
  page: Page,
  uploadButton: ReturnType<Page['getByRole']>,
  file: ReturnType<typeof pdfFile>,
  classification: string,
) {
  await uploadButton.click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.locator('input[type="file"]').setInputFiles(file);
  await dialog.getByRole('combobox').selectOption(classification);
  const submitButton = dialog.getByRole('button', { name: 'アップロード' });
  await expect(submitButton).toBeEnabled();
  await submitButton.click();
  await expect(dialog).not.toBeVisible({ timeout: 15_000 });
}

test.describe('文書ウォレット (FR-013) E2E', () => {
  test('アップロード → 一覧表示 → ダウンロード → 削除', async ({ page }) => {
    test.setTimeout(90_000);
    const state = attachDiagnostics(page);
    try {
      const suffix = Date.now().toString();
      const planId = await createGuestPlan(page, suffix);

      // 1. プランから「📄 文書」で文書ウォレット画面へ遷移
      await openDocumentsPage(page, planId);
      await expect(page.getByText('文書がまだ登録されていません')).toBeVisible();

      // 2. アップロード
      const file = pdfFile(suffix);
      const uploadButton = page.getByRole('button', { name: '新規アップロード' });
      await fillAndSubmitUpload(page, uploadButton, file, 'confidential');

      // 3. モーダルが閉じ、一覧に反映される(DBへ実際に保存されたことの
      //    確認は後続のreloadで行う)
      await expect(page.getByText(file.name)).toBeVisible({ timeout: 15_000 });
      await expect(page.getByText('機密')).toBeVisible();

      // 4. reload後も一覧に残っている(backend/DBへ永続化されたことの確認、
      //    quickdraft-flow.spec.tsと同じ考え方)
      await page.reload();
      await expect(page.getByText(file.name)).toBeVisible({ timeout: 15_000 });

      // 5. ダウンロード。backend側はContent-Disposition: attachmentを付与する
      //    ため(Gate M7 P1-01)、新規タブは即座にダウンロードへ遷移する。
      //    ポップアップの発生とURLパターンで、実際にdownload-url取得
      //    →ファイル取得の経路が動作したことを確認する。
      const popupPromise = page.waitForEvent('popup');
      await page.getByRole('button', { name: 'ダウンロード' }).click();
      const popup = await popupPromise;
      const download = await popup.waitForEvent('download', { timeout: 10_000 }).catch(() => null);
      if (download) {
        expect(download.suggestedFilename()).toBeTruthy();
      } else {
        await expect(popup).toHaveURL(/\/documents\/download/, { timeout: 10_000 });
      }
      await popup.close().catch(() => undefined);

      // 6. 削除。DocumentsPage.handleDeleteはwindow.confirm()を使うため、
      //    確認ダイアログを自動acceptする。
      page.once('dialog', (d) => d.accept());
      await page.getByRole('button', { name: '削除' }).click();

      // 7. 一覧から消え、空状態メッセージへ戻る
      await expect(page.getByText('文書がまだ登録されていません')).toBeVisible({ timeout: 15_000 });
      await expect(page.getByText(file.name)).not.toBeVisible();

      // 8. reloadしても削除が永続化されている(soft delete + purgeがUIから
      //    見て「消えたまま」であることの確認。Gate M7 P0-04)
      await page.reload();
      await expect(page.getByText('文書がまだ登録されていません')).toBeVisible({ timeout: 15_000 });
    } catch (e) {
      throw new Error(`${e instanceof Error ? e.message : String(e)}\n${diagnosticsSummary(state)}`);
    }
  });

  test('厳重管理(restricted)分類の文書を所有者自身が作成・閲覧できる', async ({ page }) => {
    test.setTimeout(90_000);
    const state = attachDiagnostics(page);
    try {
      const suffix = `restricted-${Date.now()}`;
      const planId = await createGuestPlan(page, suffix);

      const file = pdfFile(suffix);
      const uploadButton = await openDocumentsPage(page, planId);
      await fillAndSubmitUpload(page, uploadButton, file, 'restricted');

      // 所有者本人には厳重管理の文書も正しく表示される(P0-03は
      // owner本人を除外するものではない)
      await expect(page.getByText(file.name)).toBeVisible({ timeout: 15_000 });
      await expect(page.getByText('厳重管理')).toBeVisible();

      await page.reload();
      await expect(page.getByText(file.name)).toBeVisible({ timeout: 15_000 });
      await expect(page.getByText('厳重管理')).toBeVisible();
    } catch (e) {
      throw new Error(`${e instanceof Error ? e.message : String(e)}\n${diagnosticsSummary(state)}`);
    }
  });
});
